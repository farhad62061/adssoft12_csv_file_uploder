package com.ads.CsvToDatabaseUploader.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ads.CsvToDatabaseUploader.Model.CorpSummary;

@Repository
public interface CorpSummaryRepository extends JpaRepository<CorpSummary, Long> {

}
