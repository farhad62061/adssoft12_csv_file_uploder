package com.ads.CsvToDatabaseUploader.Model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "temp_corp_summary")
public class CorpSummary {
	
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "id")
	  private long id;
	  
	
		@Column(name = "SALUTATION")
		  private String salutation;
		
		@Column(name = "FULL_NAME")
		  private String fullName;
		
		
		
		@Column(name = "BSCODE")
		  private String bscode;
		
		@Column(name = "BILL_CYCLE")
		  private String bill_cycle;
		
		@Column(name = "COMPANY")
		  private String company;
		
		@Column(name = "ADDRESS_1")
		  private String address_1;
		
		@Column(name = "ADDRESS_2")
		  private String address_2;
		
		
		@Column(name = "ADDRESS_3")
		  private String address_3;
		
		@Column(name = "CITY")
		  private String city;
		
		@Column(name = "POST_CODE")
		  private String post_code;
		
		@Column(name = "KAM")
		  private String kam;
		
		@Column(name = "KAM_MOBILE")
		  private String kam_mobile;
		
		@Column(name = "E_MAIL")
		  private String e_mail;
		
		@Column(name = "E_MAIL1")
		  private String e_mail1;
		
		@Column(name = "E_MAIL2")
		  private String e_mail2;
		
		
		@Column(name = "E_MAIL3")
		  private String e_mail3;
		
		@Column(name = "E_MAIL4")
		  private String e_mail4;
		
				
		

//		public CorpSummary(long id, String salutation, String fullName, String designation, String bscode) {
//			super();
//			this.id = id;
//			this.salutation = salutation;
//			this.fullName = fullName;
//			this.designation = designation;
//			this.bscode = bscode;
//		}

//		public CorpSummary( String salutation, String fullName, String designation, String bscode) {
//			super();
//			this.salutation = salutation;
//			this.fullName = fullName;
//			this.designation = designation;
//			this.bscode = bscode;
//		}
		
		
		

		

		public CorpSummary(long id, String salutation, String fullName, String bscode, String bill_cycle,
		String company, String address_1, String address_2, String address_3, String city, String post_code, String kam,
		String kam_mobile, String e_mail, String e_mail1, String e_mail2, String e_mail3, String e_mail4) {
	super();
	this.id = id;
	this.salutation = salutation;
	this.fullName = fullName;
	this.bscode = bscode;
	this.bill_cycle = bill_cycle;
	this.company = company;
	this.address_1 = address_1;
	this.address_2 = address_2;
	this.address_3 = address_3;
	this.city = city;
	this.post_code = post_code;
	this.kam = kam;
	this.kam_mobile = kam_mobile;
	this.e_mail = e_mail;
	this.e_mail1 = e_mail1;
	this.e_mail2 = e_mail2;
	this.e_mail3 = e_mail3;
	this.e_mail4 = e_mail4;
}
		
		
		
		

		public CorpSummary(String salutation, String fullName, String bscode, String bill_cycle,
				String company, String address_1, String address_2, String address_3, String city, String post_code,
				String kam, String kam_mobile, String e_mail, String e_mail1, String e_mail2, String e_mail3,
				String e_mail4) {
			super();
			this.salutation = salutation;
			this.fullName = fullName;
			this.bscode = bscode;
			this.bill_cycle = bill_cycle;
			this.company = company;
			this.address_1 = address_1;
			this.address_2 = address_2;
			this.address_3 = address_3;
			this.city = city;
			this.post_code = post_code;
			this.kam = kam;
			this.kam_mobile = kam_mobile;
			this.e_mail = e_mail;
			this.e_mail1 = e_mail1;
			this.e_mail2 = e_mail2;
			this.e_mail3 = e_mail3;
			this.e_mail4 = e_mail4;
		}
		
		
		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getSalutation() {
			return salutation;
		}

		public void setSalutation(String salutation) {
			this.salutation = salutation;
		}

		public String getFullName() {
			return fullName;
		}

		public void setFullName(String fullName) {
			this.fullName = fullName;
		}


		public String getBscode() {
			return bscode;
		}

		public void setBscode(String bscode) {
			this.bscode = bscode;
		}

		public String getBill_cycle() {
			return bill_cycle;
		}

		public void setBill_cycle(String bill_cycle) {
			this.bill_cycle = bill_cycle;
		}

		public String getCompany() {
			return company;
		}

		public void setCompany(String company) {
			this.company = company;
		}

		public String getAddress_1() {
			return address_1;
		}

		public void setAddress_1(String address_1) {
			this.address_1 = address_1;
		}

		public String getAddress_2() {
			return address_2;
		}

		public void setAddress_2(String address_2) {
			this.address_2 = address_2;
		}

		public String getAddress_3() {
			return address_3;
		}

		public void setAddress_3(String address_3) {
			this.address_3 = address_3;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getPost_code() {
			return post_code;
		}

		public void setPost_code(String post_code) {
			this.post_code = post_code;
		}

		public String getKam() {
			return kam;
		}

		public void setKam(String kam) {
			this.kam = kam;
		}

		public String getKam_mobile() {
			return kam_mobile;
		}

		public void setKam_mobile(String kam_mobile) {
			this.kam_mobile = kam_mobile;
		}

		public String getE_mail() {
			return e_mail;
		}

		public void setE_mail(String e_mail) {
			this.e_mail = e_mail;
		}

		public String getE_mail1() {
			return e_mail1;
		}

		public void setE_mail1(String e_mail1) {
			this.e_mail1 = e_mail1;
		}

		public String getE_mail2() {
			return e_mail2;
		}

		public void setE_mail2(String e_mail2) {
			this.e_mail2 = e_mail2;
		}

		public String getE_mail3() {
			return e_mail3;
		}

		public void setE_mail3(String e_mail3) {
			this.e_mail3 = e_mail3;
		}

		public String getE_mail4() {
			return e_mail4;
		}

		public void setE_mail4(String e_mail4) {
			this.e_mail4 = e_mail4;
		}

	

		
		

}

