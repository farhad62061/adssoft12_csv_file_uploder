package com.ads.CsvToDatabaseUploader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvToDatabaseUploaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
